import React from 'react';
import EventTable from './EventTable';
import styles from './EventsPage.module.css';

const EventsPage = () => {
  const events = [
    {
      id: 1,
      name: 'Jom Derma Darah 2024',
      date: '25/12/2024',
      location: 'Dewan Utama Pelajar',
      startTime: '08:00 AM',
      endTime: '05:00 PM',
      status: 'Ongoing'
    }
  ];

  return (
    <div className={styles.pageContainer}>
      <header className={styles.header}>
        <div className={styles.headerContent}>
          <div className={styles.brandSection}>
            <h1 className={styles.logo}>BLOODCONNECT.</h1>
            <nav className={styles.navigation}>
              <a href="#" className={styles.navLink}>Event Details</a>
              <a href="#" className={styles.navLink}>Appointments</a>
              <a href="#" className={styles.navLink}>Medical Staff</a>
              <a href="#" className={styles.navLink}>Blood bank</a>
              <a href="#" className={styles.navLink}>Feedback</a>
            </nav>
          </div>
          
          <div className={styles.adminSection}>
            <span className={styles.adminName}>Admin Name</span>
            <img 
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/2b1522abc6974fbbef850fe10a9ddb8afb51e1df950ad85142b4ffd3fa741d71?placeholderIfAbsent=true&apiKey=db478cca7787456a84ce8791828a32a7" 
              alt="Admin avatar" 
              className={styles.adminAvatar}
            />
          </div>
        </div>
      </header>

      <main className={styles.mainContent}>
        <h2 className={styles.pageTitle}>Events</h2>
        <EventTable events={events} />
      </main>
    </div>
  );
};

export default EventsPage;
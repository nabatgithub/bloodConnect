import React from 'react';
import { MedicalStaffTable } from './MedicalStaffTable';
import styles from './MedicalStaffPage.module.css';

export function MedicalStaffPage() {
  return (
    <main className={styles.pageContainer}>
      <section className={styles.mainContent}>
        <h2 className={styles.pageTitle}>Medical Staff</h2>
        <div className={styles.tableWrapper}>
          <MedicalStaffTable />
        </div>
        {/* <div className={styles.buttonContainer}>
          <button className={styles.addButton}>
            Add Medical Staff
          </button>
        </div> */}
      </section>
    </main>
  );
}
